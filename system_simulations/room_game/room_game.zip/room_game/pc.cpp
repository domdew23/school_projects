#include <iostream>
#include <string>
#include <vector>
#include "creature.h"
#include "room.h"
#include "pc.h"
using namespace std;

bool PC::react(string action, bool this_creat, int* respect){
	cout << "ERROR: This should not be called." << endl;
}
